public class ThermostatAdapter implements SmartDevice {
    private final LegacyThermostat thermostat;

    public ThermostatAdapter(LegacyThermostat thermostat) {
        if (thermostat == null) {
            throw new IllegalArgumentException("Thermostat cannot be null");
        }
        this.thermostat = thermostat;
    }

    public void turnOn() {
        String dial = thermostat.checkDial();

        if ("IDLE".equals(dial)) {
            thermostat.rotateDial("LOW");
        }
    }

    public void turnOff() {
        thermostat.rotateDial("IDLE");
    }

    public boolean isOn() {
        String dial = thermostat.checkDial();
        if (dial == null) {
            return false;
        }

        if (dial.equals("LOW") || dial.equals("MEDIUM") || dial.equals("MAX")) {
            return true;
        }
        return false;
    }

    public int getPowerPercent() {
        String dial = thermostat.checkDial();
        if (dial == null) {
            return -1;
        }

        if (dial.equals("IDLE")) {
            return 0;
        } else if (dial.equals("LOW")) {
            return 33;
        } else if (dial.equals("MEDIUM")) {
            return 66;
        } else if (dial.equals("MAX")) {
            return 100;
        } else {

            return -1;
        }
    }
}