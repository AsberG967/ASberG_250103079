public class BulbAdapter implements SmartDevice {
    private final LegacyBulb bulb;
    private static final int K = 9;

    public BulbAdapter(LegacyBulb bulb) {
        if (bulb == null) {
            throw new IllegalArgumentException("Bulb cannot be null");
        }
        this.bulb = bulb;
    }

    public void turnOn() {
        bulb.setBrightness(255);
    }

    public void turnOff() {
        bulb.setBrightness(0);
    }

    public boolean isOn() {

        if (!bulb.hasPower()) {
            return false;
        }
        return bulb.readBrightness() > 0;
    }

    public int getPowerPercent() {

        if (!bulb.hasPower() || bulb.readBrightness() == 0) {
            return 0;
        }

        int rawBrightness = bulb.readBrightness();
        int rawPercent = (rawBrightness * 100) / 255;
        int calibratedPercent = rawPercent + K;

        if (calibratedPercent > 100) {
            return 100;
        }
        return calibratedPercent;
    }
}