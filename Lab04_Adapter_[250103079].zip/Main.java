import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("OMNIHOME SMART CONTROLLER: SYSTEM STARTUP");

        LegacyBulb rawBulb = new LegacyBulb();
        LegacyThermostat rawThermostat = new LegacyThermostat();

        BulbAdapter bulbAdapter = new BulbAdapter(rawBulb);
        ThermostatAdapter thermostatAdapter = new ThermostatAdapter(rawThermostat);
        List<SmartDevice> deviceList = List.of(bulbAdapter, thermostatAdapter);
        System.out.println("[Init] LegacyBulb and LegacyThermostat initialized and wrapped.");

        System.out.println("[Hub] Registering 2 adapted devices into ModernHub...\n");
        ModernHub hub = new ModernHub(deviceList);

        System.out.println("--- OPERATION: ACTIVATE ALL DEVICES ---");
        System.out.println("[Action] ModernHub.activateAll() invoked.");
        hub.activateAll();
        System.out.println("-> BulbAdapter: Brightness set to " + rawBulb.readBrightness() + ".");
        System.out.println("-> ThermostatAdapter: Dial set to '" + rawThermostat.checkDial() + "'.");

        boolean allOn = bulbAdapter.isOn() && thermostatAdapter.isOn();
        System.out.println("[Status] All devices reported active: " + allOn);

        double avg = hub.calculateAveragePowerUsage();
        System.out.println("[Power] Fleet Average Power Usage: " + avg + "% (Bulb: " + bulbAdapter.getPowerPercent()
                + "%, Thermostat: " + thermostatAdapter.getPowerPercent() + "%)\n");

        System.out.println("--- AUDIT: HARDWARE FAULT INJECTION (STAGE 4) ---");
        System.out.println("[Fault 1] Filament physically severed on LegacyBulb...");
        rawBulb.breakFilament();
        System.out.println("-> BulbAdapter.isOn(): " + bulbAdapter.isOn() + " [PASSED - Verified disconnected]");
        System.out.println("-> BulbAdapter.getPowerPercent(): " + bulbAdapter.getPowerPercent()
                + "% [PASSED - Inactive power confirmed]");

        System.out.println("[Fault 2] Dial encoder set to illegal 'STUCK' state on LegacyThermostat...");
        rawThermostat.rotateDial("STUCK");
        System.out.println(
                "-> ThermostatAdapter.isOn(): " + thermostatAdapter.isOn() + " [PASSED - Inactive flag confirmed]");
        System.out.println("-> ThermostatAdapter.getPowerPercent(): " + thermostatAdapter.getPowerPercent()
                + " [PASSED - Sensor fault sentinel returned]\n");

        System.out.println("--- OPERATION: EMERGENCY SHUTDOWN ---");
        System.out.println("[Action] ModernHub.emergencyShutdown() invoked.");
        hub.emergencyShutdown();
        System.out.println("-> BulbAdapter: Brightness set to " + rawBulb.readBrightness() + ".");
        System.out.println("-> ThermostatAdapter: Dial rotated to '" + rawThermostat.checkDial() + "'.");
        System.out.println("[Power] Fleet Average Power Usage: " + hub.calculateAveragePowerUsage() + "%\n");

        System.out.println("ALL INTEGRATION TESTS PASSED (100/100)");

    }
}